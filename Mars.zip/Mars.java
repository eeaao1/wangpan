package mars;

import java.math.BigInteger;
import java.util.Scanner;

public class Mars {

    private static BigInteger[] steps = {BigInteger.valueOf(0), BigInteger.valueOf(0)};

    private static BigInteger[] mapSize = new BigInteger[2];

    private static BigInteger[] location = new BigInteger[2];

    private static String[] directions = {"N", "E", "S", "W"};

    private static Integer currentDirectionInt;

    public static void main(String[] args) {
        StringBuilder result = new StringBuilder();
        Scanner in = new Scanner(System.in);
        String line = "";
        while (true) {
            System.out.println("Please type map size.(like 5 5)");
            line = in.nextLine();
            String[] input = line.split(" ");
            if (input.length > 1) {
                try {
                    mapSize[0] = new BigInteger(input[1].trim());
                    mapSize[1] = new BigInteger(input[0].trim());
                    System.out.println("Set map size:" + mapSize[0] + " " + mapSize[1]);
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("type formate error");
                }
            } else {
                System.out.println("type formate error");
            }
        }
        while (true) {
            while (true) {
                System.out.println("Please type location and Direction.(like 1 2 N)");
                line = in.nextLine();
                String[] input = line.split(" ");
                if (input.length > 2) {
                    try {
                        location[0] = new BigInteger(input[1].trim());
                        location[1] = new BigInteger(input[0].trim());
                        if (location[0].max(mapSize[0]).equals(location[0])
                                || location[1].max(mapSize[1]).equals(location[1]))
                        {
                            System.out.println("type error location biger then map size");
                            continue;
                        }
                        String currentDirection = input[2].trim().toUpperCase();
                        if (!"N".equals(currentDirection) && !"S".equals(currentDirection)
                                && !"W".equals(currentDirection)
                                && !"E".equals(currentDirection))
                        {
                            System.out.println("type formate error");
                            continue;
                        }
                        currentDirectionInt =
                                getCurrentDirectionInt(directions, currentDirection);
                        System.out.println("Set location:" + location[0] + " " + location[1]
                                + " ,and Direction:" + currentDirection);
                        break;
                    } catch (NumberFormatException e) {
                        System.out.println("type formate error");
                    }
                } else {
                    System.out.println("type formate error");
                }
            }
            System.out.println("Please type move step.(like LMLMLMLMM)");
            line = in.nextLine();
            if (!line.matches("[z-zA-Z]")) {
                System.out.println("type formate error");
                continue;
            }
            String moveString = line.trim().toUpperCase();
            System.out.println("Set move step: " + moveString);
            result.append(getLocation(moveString) + "\n");
            System.out.println("type 'exit' to exit, and type other words to continue.");
            line = in.nextLine();
            if ("exit".equalsIgnoreCase(line.trim())) {
                System.out.println("exit......");
                break;
            }
        }
        System.out.println(result.toString());
    }

    public static String getLocation(String moveString) {
        move(moveString);
        return location[1].add(steps[1]).toString() + " " + location[0].add(steps[0]).toString()
                + " " + directions[currentDirectionInt];
    }

    public static void move(String moveString) {
        char[] moves = moveString.toCharArray();
        for (char c : moves) {
            if (c == 'L') {
                turnLeft();
            } else if (c == 'R') {
                turnRight();
            } else if (c == 'M') {
                moveq();
            }
        }
    }

    public static void turnLeft() {
        if (currentDirectionInt.equals(0)) {
            currentDirectionInt = 3;
        } else {
            currentDirectionInt--;
        }
    }

    public static void turnRight() {
        if (currentDirectionInt.equals(3)) {
            currentDirectionInt = 0;
        } else {
            currentDirectionInt++;
        }
    }

    public static void moveq() {
        if (currentDirectionInt.equals(0) && isOutOfAdd(0)) {
            steps[0] = steps[0].add(BigInteger.valueOf(1));
        }
        if (currentDirectionInt.equals(1) && isOutOfAdd(1)) {
            steps[1] = steps[1].add(BigInteger.valueOf(1));
        }
        if (currentDirectionInt.equals(2) && isOutOfSub(0)) {
            steps[0] = steps[0].subtract(BigInteger.valueOf(1));
        }
        if (currentDirectionInt.equals(3) && isOutOfSub(1)) {
            steps[1] = steps[1].subtract(BigInteger.valueOf(1));
        }
    }

    public static boolean isOutOfAdd(Integer index) {
        BigInteger temp = location[index].add(steps[index]).add(BigInteger.valueOf(1));
        return temp.max(mapSize[index]).equals(mapSize[index]);
    }

    public static boolean isOutOfSub(Integer index) {
        BigInteger temp = location[index].add(steps[index]).subtract(BigInteger.valueOf(1));
        return temp.min(BigInteger.valueOf(0)).equals(BigInteger.valueOf(0));
    }

    public static Integer getCurrentDirectionInt(String[] directions, String currentDirection) {
        for (int i = 0; i < 4; i++) {
            if (directions[i].equals(currentDirection)) {
                return i;
            }
        }
        return null;
    }
}
